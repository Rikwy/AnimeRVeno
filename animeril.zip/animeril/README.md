# AnimeRil – منصة الأنمي

Next.js 14 (App Router) · TypeScript · Tailwind CSS · Framer Motion · Lucide · AniList GraphQL.

## التشغيل
```bash
npm install
cp .env.example .env.local
npm run dev          # http://localhost:3000
npm run typecheck && npm run build
```

## لماذا هذه البنية؟
- **Next.js**: عرض من السيرفر (سرعة + SEO) مع Cache مدمج لطلبات AniList، وملفات API داخلية تخفي منطق المصادر.
- **فصل المسؤوليات**: `src/lib` للبيانات والمنطق، `src/components` للواجهة، `src/app/api` للوسيط بين الواجهة والمصادر.

## الصفحات
`/` الرئيسية · `/browse` الاستكشاف (فلاتر + Infinite Scroll مرتبطة بـ AniList) · `/search` بحث مباشر · `/anime/[id]` التفاصيل · `/watch/[id]/[episode]` المشاهدة · `/favorites` المفضلة والمتابعة (LocalStorage).

## مصادر الحلقات (Episode providers)
AniList يوفّر بيانات الأنمي وعدد الحلقات فقط، **ولا يوفّر روابط مشاهدة**. لذلك:
- لا يوجد API رسمي معروف لـ Anime3rb، والمشروع **لا يسحب الموقع**. المحوّل `src/lib/providers/anime3rb.ts` يتوقع نقطة نهاية **مصرّح لك باستخدامها**:
  ```
  GET {ANIME3RB_API_BASE}/servers?anilistId=<id>&episode=<n>
  → { "servers": [ { "name": "...", "url": "https://...", "quality": "720p" } ] }
  ```
- بدون ضبط `ANIME3RB_API_BASE` يعرض موقع المشاهدة رسالة "لا يتوفر مصدر" بدل أي روابط وهمية.
- لإضافة مصدر آخر: أنشئ ملفاً يطبّق `EpisodeProvider` وسجّله في `providers/registry.ts`.

## Ezv Player
`VideoPlayer` يعرض رابط المشغّل داخل iframe معزول (`sandbox`). لا يُعرض أي رابط إلا إذا كان `https` ونطاقه ضمن `ALLOWED_EMBED_HOSTS` (يُتحقق منه في `/api/episodes` ويُفرض أيضاً عبر CSP `frame-src` في `next.config.mjs`). ضع نطاق Ezv الذي لديك إذن باستخدامه في هذا المتغير.

## الأمان
لا مفاتيح في الواجهة (متغيرات البيئة للسيرفر فقط) · الوصف يُعرض كنص بلا `dangerouslySetInnerHTML` · التحقق من كل معاملات `/api/anime` و`/api/episodes` · رؤوس أمان في `next.config.mjs`.

## حالة الاختبار (صراحةً)
- **اختُبر فعلياً**: منطق التحقق من روابط التشغيل (9 حالات بينها `javascript:` و`http` و`user@host` ونطاقات مخادعة) وقراءة استجابة المصادر وثوابت الفلاتر.
- **لم يُختبر**: بناء المشروع وتشغيله، واستعلامات AniList الحية، والتصميم على الشاشات — بيئة التنفيذ التي كُتب فيها لا تملك إنترنت لتثبيت الحزم. شغّل `npm run typecheck && npm run build` أولاً، وأرسل لي أي خطأ يظهر لأصلحه.
- **غير مُتحقق منه**: عمل Ezv Player مع مصدر حقيقي (يحتاج مصدراً مصرّحاً به).
- AniList لا يوفّر اسماً عربياً؛ يظهر الاسم العربي فقط إذا وُجد ضمن مرادفات الأنمي.
