const hosts = (process.env.ALLOWED_EMBED_HOSTS ?? '')
  .split(',')
  .map((h) => h.trim().toLowerCase())
  .filter(Boolean);

const frameSrc = hosts.length
  ? `frame-src 'self' ${hosts.map((h) => `https://${h} https://*.${h}`).join(' ')}`
  : "frame-src 'none'";

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: { remotePatterns: [{ protocol: 'https', hostname: '**.anilist.co' }] },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
          { key: 'Content-Security-Policy', value: frameSrc },
        ],
      },
    ];
  },
};

export default nextConfig;
