import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: '#080B14',
        surface: '#101625',
        primary: '#8B5CF6',
        accent: '#06B6D4',
        fg: '#F8FAFC',
        muted: '#94A3B8',
      },
      fontFamily: { sans: ['var(--font-arabic)', 'system-ui', 'sans-serif'] },
      boxShadow: {
        glow: '0 0 24px -4px rgba(139,92,246,.55)',
        'glow-accent': '0 0 24px -4px rgba(6,182,212,.5)',
      },
      keyframes: {
        shimmer: { '100%': { transform: 'translateX(-100%)' } },
      },
      animation: { shimmer: 'shimmer 1.6s infinite' },
    },
  },
  plugins: [],
};
export default config;
