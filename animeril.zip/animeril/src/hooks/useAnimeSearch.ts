import { useEffect, useState } from 'react';
import type { AnimeSummary } from '@/lib/types';

interface State {
  items: AnimeSummary[];
  loading: boolean;
  error: string | null;
}

/** Live search against /api/anime (which proxies AniList). Pass an already-debounced query. */
export function useAnimeSearch(query: string, perPage = 24): State {
  const [state, setState] = useState<State>({ items: [], loading: false, error: null });

  useEffect(() => {
    const q = query.trim();
    if (q.length < 2) {
      setState({ items: [], loading: false, error: null });
      return;
    }
    const ctrl = new AbortController();
    setState((s) => ({ ...s, loading: true, error: null }));
    fetch(`/api/anime?q=${encodeURIComponent(q)}&perPage=${perPage}`, { signal: ctrl.signal })
      .then(async (r) => {
        const json = await r.json();
        if (!r.ok) throw new Error(json.error ?? 'فشل البحث');
        setState({ items: json.items as AnimeSummary[], loading: false, error: null });
      })
      .catch((e: unknown) => {
        if (e instanceof DOMException && e.name === 'AbortError') return;
        setState({ items: [], loading: false, error: e instanceof Error ? e.message : 'فشل البحث' });
      });
    return () => ctrl.abort();
  }, [query, perPage]);

  return state;
}
