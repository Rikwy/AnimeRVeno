'use client';

import { useState } from 'react';
import { cn } from '@/lib/utils';
import { EpisodeCard } from './EpisodeCard';

const STEP = 60;

export function EpisodeList({ animeId, total, current, compact = false }: { animeId: number; total: number; current?: number; compact?: boolean }) {
  const [limit, setLimit] = useState(() => Math.max(STEP, current ? Math.ceil(current / STEP) * STEP : STEP));
  const shown = Math.min(total, limit);

  return (
    <div>
      <div
        className={cn(
          'grid gap-2',
          compact ? 'max-h-[28rem] grid-cols-5 overflow-y-auto pe-1 sm:grid-cols-8 lg:grid-cols-4' : 'grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10',
        )}
      >
        {Array.from({ length: shown }, (_, i) => i + 1).map((n) => (
          <EpisodeCard key={n} animeId={animeId} number={n} active={n === current} />
        ))}
      </div>
      {shown < total && (
        <button type="button" onClick={() => setLimit((l) => l + STEP)} className="btn-glass mt-4 w-full">
          عرض المزيد ({total - shown} حلقة متبقية)
        </button>
      )}
    </div>
  );
}
