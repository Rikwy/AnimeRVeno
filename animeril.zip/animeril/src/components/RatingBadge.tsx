import { Star } from 'lucide-react';
import { cn, formatScore } from '@/lib/utils';

export function RatingBadge({ score, className }: { score: number | null; className?: string }) {
  const s = formatScore(score);
  if (!s) return null;
  return (
    <span
      className={cn('glass inline-flex items-center gap-1 rounded-lg px-2 py-0.5 text-xs font-bold text-fg', className)}
      title="التقييم من 10"
    >
      <Star className="h-3 w-3 fill-amber-400 text-amber-400" aria-hidden="true" />
      {s}
    </span>
  );
}
