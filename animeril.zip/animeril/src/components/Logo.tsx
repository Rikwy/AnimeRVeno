import Link from 'next/link';

export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="ar-grad" x1="4" y1="36" x2="36" y2="4" gradientUnits="userSpaceOnUse">
          <stop stopColor="#8B5CF6" />
          <stop offset="1" stopColor="#06B6D4" />
        </linearGradient>
        <filter id="ar-glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="1.6" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <rect x="1" y="1" width="38" height="38" rx="11" fill="#101625" stroke="url(#ar-grad)" strokeOpacity=".5" />
      <g filter="url(#ar-glow)">
        <path d="M9 31 20 9l11 22" stroke="url(#ar-grad)" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M17.2 20.5v6.6l5.6-3.3-5.6-3.3Z" fill="url(#ar-grad)" />
      </g>
    </svg>
  );
}

export function Logo({ className = '' }: { className?: string }) {
  return (
    <Link href="/" aria-label="AnimeRil – الصفحة الرئيسية" className={`inline-flex items-center gap-2.5 ${className}`}>
      <LogoMark />
      <span dir="ltr" className="text-xl font-extrabold tracking-tight">
        Anime<span className="text-gradient">Ril</span>
      </span>
    </Link>
  );
}
