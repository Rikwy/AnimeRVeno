import Link from 'next/link';
import { Logo } from './Logo';

export function Footer() {
  return (
    <footer className="mt-20 border-t border-white/10 bg-surface/40">
      <div className="container-page grid gap-8 py-10 md:grid-cols-[2fr_1fr_1fr]">
        <div className="space-y-3">
          <Logo />
          <p className="max-w-md text-sm leading-relaxed text-muted">
            AnimeRil دليل عربي لاستكشاف الأنمي ومتابعته. بيانات العناوين والتقييمات والمواسم من AniList.
          </p>
        </div>
        <nav aria-label="روابط الموقع" className="flex flex-col gap-2 text-sm">
          <span className="font-semibold">الموقع</span>
          <Link href="/" className="text-muted hover:text-fg">الرئيسية</Link>
          <Link href="/browse" className="text-muted hover:text-fg">استكشاف</Link>
          <Link href="/search" className="text-muted hover:text-fg">بحث</Link>
          <Link href="/favorites" className="text-muted hover:text-fg">المفضلة</Link>
        </nav>
        <div className="flex flex-col gap-2 text-sm">
          <span className="font-semibold">ملاحظات</span>
          <p className="text-muted leading-relaxed">
            الموقع لا يستضيف أي ملفات فيديو. روابط التشغيل تأتي من مصادر مصرّح بها يضبطها مالك الموقع.
          </p>
        </div>
      </div>
      <div className="border-t border-white/5 py-4 text-center text-xs text-muted">
        © {new Date().getFullYear()} AnimeRil
      </div>
    </footer>
  );
}
