'use client';

import { RotateCcw, Search, SlidersHorizontal } from 'lucide-react';
import { useEffect, useState } from 'react';
import { GENRES, SEASON_AR, SEASON_VALUES, SORT_OPTIONS, STATUS_AR, STATUS_VALUES, yearOptions } from '@/lib/constants';
import { useDebouncedValue } from '@/hooks/useDebouncedValue';

export interface Filters {
  q: string;
  genre: string;
  year: string;
  status: string;
  season: string;
  sort: string;
}

interface Props {
  value: Filters;
  onChange: (patch: Partial<Filters>) => void;
  onReset: () => void;
}

function Select({ id, label, value, onChange, children }: { id: string; label: string; value: string; onChange: (v: string) => void; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="text-xs text-muted">{label}</label>
      <select id={id} value={value} onChange={(e) => onChange(e.target.value)} className="field">
        {children}
      </select>
    </div>
  );
}

export function FilterPanel({ value, onChange, onReset }: Props) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState(value.q);
  const debouncedQ = useDebouncedValue(q, 400);

  useEffect(() => setQ(value.q), [value.q]);
  useEffect(() => {
    if (debouncedQ !== value.q) onChange({ q: debouncedQ });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedQ]);

  const sort = value.sort || (value.q ? 'SEARCH_MATCH' : 'POPULARITY_DESC');
  const years = yearOptions();
  const active = [value.genre, value.year, value.status, value.season, value.q].filter(Boolean).length;

  return (
    <section aria-label="الفلاتر" className="glass rounded-2xl p-4">
      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <label htmlFor="browse-q" className="sr-only">البحث بالاسم</label>
          <Search className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <input id="browse-q" value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث بالاسم…" className="field ps-9" />
        </div>
        <button type="button" onClick={() => setOpen((v) => !v)} aria-expanded={open} className="btn-glass lg:hidden">
          <SlidersHorizontal className="h-4 w-4" />
          الفلاتر{active > 0 && ` (${active})`}
        </button>
      </div>

      <div className={`${open ? 'grid' : 'hidden'} mt-4 grid-cols-2 gap-3 lg:grid lg:grid-cols-6`}>
        <Select id="f-genre" label="التصنيف" value={value.genre} onChange={(v) => onChange({ genre: v })}>
          <option value="">الكل</option>
          {GENRES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </Select>
        <Select id="f-year" label="سنة الإنتاج" value={value.year} onChange={(v) => onChange({ year: v })}>
          <option value="">الكل</option>
          {years.map((y) => <option key={y} value={y}>{y}</option>)}
        </Select>
        <Select id="f-status" label="الحالة" value={value.status} onChange={(v) => onChange({ status: v })}>
          <option value="">الكل</option>
          {STATUS_VALUES.map((s) => <option key={s} value={s}>{STATUS_AR[s]}</option>)}
        </Select>
        <Select id="f-season" label="الموسم" value={value.season} onChange={(v) => onChange({ season: v })}>
          <option value="">الكل</option>
          {SEASON_VALUES.map((s) => <option key={s} value={s}>{SEASON_AR[s]}</option>)}
        </Select>
        <Select id="f-sort" label="الترتيب" value={sort} onChange={(v) => onChange({ sort: v })}>
          {SORT_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </Select>
        <div className="flex items-end">
          <button type="button" onClick={onReset} className="btn-glass w-full" disabled={active === 0 && !value.sort}>
            <RotateCcw className="h-4 w-4" /> إعادة ضبط
          </button>
        </div>
      </div>
    </section>
  );
}
