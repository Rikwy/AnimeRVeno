import { cn } from '@/lib/utils';

export function Skeleton({ className }: { className?: string }) {
  return (
    <div className={cn('relative overflow-hidden rounded-xl bg-white/5', className)} aria-hidden="true">
      <div className="absolute inset-0 animate-shimmer bg-gradient-to-r from-transparent via-white/10 to-transparent" />
    </div>
  );
}

export function CardSkeleton() {
  return (
    <div className="glass overflow-hidden rounded-2xl">
      <Skeleton className="aspect-[2/3] rounded-none" />
      <div className="space-y-2 p-3">
        <Skeleton className="h-3 w-4/5" />
        <Skeleton className="h-3 w-1/2" />
      </div>
    </div>
  );
}

export function GridSkeleton({ count = 12 }: { count?: number }) {
  return (
    <div role="status" aria-label="جارٍ التحميل" className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
      {Array.from({ length: count }, (_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  );
}

export function SliderSkeleton() {
  return (
    <div role="status" aria-label="جارٍ التحميل" className="flex gap-4 overflow-hidden">
      {Array.from({ length: 8 }, (_, i) => (
        <div key={i} className="w-36 shrink-0 sm:w-40 md:w-44">
          <CardSkeleton />
        </div>
      ))}
    </div>
  );
}
