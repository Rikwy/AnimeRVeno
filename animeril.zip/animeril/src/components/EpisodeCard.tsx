import Link from 'next/link';
import { cn } from '@/lib/utils';

export function EpisodeCard({ animeId, number, active = false }: { animeId: number; number: number; active?: boolean }) {
  return (
    <Link
      href={`/watch/${animeId}/${number}`}
      aria-current={active ? 'page' : undefined}
      className={cn(
        'glass flex flex-col items-center justify-center rounded-xl py-3 text-center transition hover:-translate-y-0.5 hover:border-primary/60',
        active && 'border-primary bg-primary/20 shadow-glow',
      )}
    >
      <span className="text-xs text-muted">الحلقة</span>
      <span className="text-lg font-bold">{number}</span>
    </Link>
  );
}
