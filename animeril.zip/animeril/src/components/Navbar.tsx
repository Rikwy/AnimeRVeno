'use client';

import { Menu, Search, X } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import { Logo } from './Logo';
import { SearchBar } from './SearchBar';

const LINKS = [
  { href: '/', label: 'الرئيسية' },
  { href: '/browse', label: 'استكشاف' },
  { href: '/favorites', label: 'المفضلة' },
];

export function Navbar() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [menu, setMenu] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setMenu(false), [pathname]);

  const isActive = (href: string) => (href === '/' ? pathname === '/' : pathname.startsWith(href));

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-40 transition-all duration-300',
        scrolled || menu ? 'glass-strong rounded-none border-x-0 border-t-0' : 'bg-gradient-to-b from-base/80 to-transparent',
      )}
    >
      <div className="container-page flex h-16 items-center gap-4 lg:gap-8">
        <Logo />
        <nav aria-label="التنقل الرئيسي" className="hidden items-center gap-1 md:flex">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              aria-current={isActive(l.href) ? 'page' : undefined}
              className={cn(
                'rounded-lg px-3 py-2 text-sm font-medium transition hover:text-fg',
                isActive(l.href) ? 'bg-white/10 text-fg' : 'text-muted',
              )}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="ms-auto hidden w-full max-w-sm md:block">
          <SearchBar />
        </div>
        <div className="ms-auto flex items-center gap-1 md:hidden">
          <Link href="/search" aria-label="بحث" className="grid h-10 w-10 place-items-center rounded-xl hover:bg-white/10">
            <Search className="h-5 w-5" />
          </Link>
          <button
            type="button"
            aria-label={menu ? 'إغلاق القائمة' : 'فتح القائمة'}
            aria-expanded={menu}
            onClick={() => setMenu((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-xl hover:bg-white/10"
          >
            {menu ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {menu && (
        <nav aria-label="القائمة" className="container-page flex flex-col gap-1 pb-4 md:hidden">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={cn('rounded-xl px-4 py-3 text-sm font-medium', isActive(l.href) ? 'bg-white/10' : 'text-muted')}
            >
              {l.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
