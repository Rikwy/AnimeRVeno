import Image from 'next/image';
import Link from 'next/link';
import { FORMAT_AR } from '@/lib/constants';
import type { AnimeSummary } from '@/lib/types';
import { getTitle } from '@/lib/utils';
import { FavoriteButton } from './FavoriteButton';
import { RatingBadge } from './RatingBadge';

export function AnimeCard({ anime, priority = false }: { anime: AnimeSummary; priority?: boolean }) {
  const title = getTitle(anime.title);
  const cover = anime.coverImage.extraLarge ?? anime.coverImage.large;
  const meta = [anime.seasonYear, anime.format ? FORMAT_AR[anime.format] ?? anime.format : null].filter(Boolean).join(' • ');

  return (
    <article className="group relative">
      <Link
        href={`/anime/${anime.id}`}
        className="glass block overflow-hidden rounded-2xl transition duration-300 hover:-translate-y-1 hover:shadow-glow"
      >
        <div className="relative aspect-[2/3] bg-surface" style={{ backgroundColor: anime.coverImage.color ?? undefined }}>
          {cover && (
            <Image
              src={cover}
              alt={title}
              fill
              sizes="(max-width:640px) 45vw, (max-width:1024px) 22vw, 15vw"
              priority={priority}
              className="object-cover transition-transform duration-500 group-hover:scale-105"
            />
          )}
          <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-base/80 to-transparent" />
          <RatingBadge score={anime.averageScore} className="absolute start-2 top-2" />
        </div>
        <div className="p-3">
          <h3 dir="auto" className="line-clamp-2 min-h-[2.5rem] text-sm font-semibold leading-snug">
            {title}
          </h3>
          {meta && <p className="mt-1 text-xs text-muted">{meta}</p>}
        </div>
      </Link>
      <FavoriteButton anime={anime} variant="icon" className="absolute end-2 top-2" />
    </article>
  );
}
