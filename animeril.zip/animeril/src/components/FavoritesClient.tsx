'use client';

import { Bell, Heart, X } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import { FORMAT_AR } from '@/lib/constants';
import { favoritesStore, followingStore, useSaved, type SavedAnime } from '@/lib/saved-store';
import { cn } from '@/lib/utils';
import { EmptyState } from './EmptyState';
import { RatingBadge } from './RatingBadge';

type Tab = 'favorites' | 'following';

function SavedCard({ item, onRemove }: { item: SavedAnime; onRemove: () => void }) {
  const meta = [item.year, item.format ? FORMAT_AR[item.format] ?? item.format : null].filter(Boolean).join(' • ');
  return (
    <article className="group relative">
      <Link href={`/anime/${item.id}`} className="glass block overflow-hidden rounded-2xl transition hover:-translate-y-1 hover:shadow-glow">
        <div className="relative aspect-[2/3] bg-surface">
          {item.cover && <Image src={item.cover} alt={item.title} fill sizes="(max-width:640px) 45vw, 15vw" className="object-cover" />}
          <RatingBadge score={item.score} className="absolute start-2 top-2" />
        </div>
        <div className="p-3">
          <h3 dir="auto" className="line-clamp-2 min-h-[2.5rem] text-sm font-semibold">{item.title}</h3>
          {meta && <p className="mt-1 text-xs text-muted">{meta}</p>}
        </div>
      </Link>
      <button type="button" onClick={onRemove} aria-label={`إزالة ${item.title}`} className="glass absolute end-2 top-2 grid h-8 w-8 place-items-center rounded-full hover:text-rose-300">
        <X className="h-4 w-4" />
      </button>
    </article>
  );
}

export function FavoritesClient() {
  const [tab, setTab] = useState<Tab>('favorites');
  const favorites = useSaved(favoritesStore);
  const following = useSaved(followingStore);
  const list = tab === 'favorites' ? favorites : following;
  const store = tab === 'favorites' ? favoritesStore : followingStore;

  const tabs: { id: Tab; label: string; icon: typeof Heart; count: number }[] = [
    { id: 'favorites', label: 'المفضلة', icon: Heart, count: favorites.length },
    { id: 'following', label: 'أتابعها', icon: Bell, count: following.length },
  ];

  return (
    <div className="space-y-6">
      <div role="tablist" className="glass inline-flex rounded-xl p-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            role="tab"
            type="button"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            className={cn('inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm transition', tab === t.id ? 'bg-primary/25 text-fg' : 'text-muted hover:text-fg')}
          >
            <t.icon className="h-4 w-4" />
            {t.label} ({t.count})
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <EmptyState
          icon={tab === 'favorites' ? Heart : Bell}
          title={tab === 'favorites' ? 'قائمة المفضلة فارغة' : 'لا تتابع أي أنمي بعد'}
          description="اضغط على الأيقونة في أي بطاقة أو صفحة أنمي لإضافتها هنا. تُحفظ القائمة على هذا الجهاز."
          action={{ label: 'استكشاف الأنمي', href: '/browse' }}
        />
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {list.map((item) => (
            <SavedCard key={item.id} item={item} onRemove={() => store.remove(item.id)} />
          ))}
        </div>
      )}
    </div>
  );
}
