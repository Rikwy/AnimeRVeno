'use client';

import { Server } from 'lucide-react';
import type { ServerSource } from '@/lib/providers/types';
import { cn } from '@/lib/utils';

interface Props {
  servers: ServerSource[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}

export function ServerSelector({ servers, selectedId, onSelect }: Props) {
  if (servers.length === 0) return null;
  return (
    <div role="radiogroup" aria-label="السيرفرات المتاحة" className="flex flex-wrap gap-2">
      {servers.map((s) => {
        const active = s.id === selectedId;
        return (
          <button
            key={s.id}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onSelect(s.id)}
            className={cn(
              'glass inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm transition hover:border-primary/60',
              active && 'border-primary bg-primary/20 shadow-glow',
            )}
          >
            <Server className="h-4 w-4" />
            {s.name}
            {s.quality && <span className="rounded-md bg-white/10 px-1.5 py-0.5 text-[11px] text-accent">{s.quality}</span>}
          </button>
        );
      })}
    </div>
  );
}
