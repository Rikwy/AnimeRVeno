'use client';

import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Compass, Info } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { FORMAT_AR, STATUS_AR } from '@/lib/constants';
import type { AnimeSummary } from '@/lib/types';
import { cleanDescription, cn, getTitle } from '@/lib/utils';
import { RatingBadge } from './RatingBadge';

export function HeroBanner({ items }: { items: AnimeSummary[] }) {
  const [index, setIndex] = useState(0);
  const reduce = useReducedMotion();

  useEffect(() => {
    if (reduce || items.length < 2) return;
    const t = setInterval(() => setIndex((i) => (i + 1) % items.length), 8000);
    return () => clearInterval(t);
  }, [reduce, items.length]);

  const a = items[index];
  if (!a) return null;
  const title = getTitle(a.title);
  const meta = [
    a.seasonYear,
    a.format ? FORMAT_AR[a.format] ?? a.format : null,
    a.status ? STATUS_AR[a.status] : null,
    a.episodes ? `${a.episodes} حلقة` : null,
  ].filter(Boolean);

  return (
    <section aria-label="أنمي مميز" className="relative -mt-16 min-h-[520px] overflow-hidden sm:h-[78vh]">
      <AnimatePresence mode="sync">
        <motion.div
          key={a.id}
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: reduce ? 0 : 0.9 }}
        >
          {a.bannerImage && <Image src={a.bannerImage} alt="" fill priority sizes="100vw" className="object-cover" />}
        </motion.div>
      </AnimatePresence>
      <div className="absolute inset-0 bg-gradient-to-t from-base via-base/60 to-base/20" />
      <div className="absolute inset-0 bg-gradient-to-l from-base/90 via-base/40 to-transparent" />

      <div className="container-page relative flex h-full min-h-[520px] flex-col justify-end pb-16 pt-32 sm:pb-24">
        <motion.div
          key={a.id}
          initial={reduce ? false : { opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="max-w-2xl space-y-4"
        >
          <div className="flex flex-wrap items-center gap-2">
            <RatingBadge score={a.averageScore} />
            {meta.map((m) => (
              <span key={String(m)} className="glass rounded-lg px-2.5 py-0.5 text-xs text-muted">
                {m}
              </span>
            ))}
          </div>
          <h1 dir="auto" className="text-3xl font-extrabold leading-tight drop-shadow sm:text-5xl">
            {title}
          </h1>
          <p className="line-clamp-3 max-w-xl text-sm leading-relaxed text-fg/80 sm:text-base">
            {cleanDescription(a.description)}
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <Link href={`/anime/${a.id}`} className="btn-primary">
              <Info className="h-4 w-4" /> مشاهدة التفاصيل
            </Link>
            <Link href="/browse" className="btn-glass">
              <Compass className="h-4 w-4" /> استكشاف الأنمي
            </Link>
          </div>
        </motion.div>

        {items.length > 1 && (
          <div className="absolute inset-x-0 bottom-6 flex justify-center gap-2" role="tablist" aria-label="اختيار الأنمي المميز">
            {items.map((it, i) => (
              <button
                key={it.id}
                type="button"
                role="tab"
                aria-selected={i === index}
                aria-label={getTitle(it.title)}
                onClick={() => setIndex(i)}
                className={cn('h-2 rounded-full transition-all', i === index ? 'w-8 bg-gradient-to-l from-primary to-accent' : 'w-2 bg-white/30 hover:bg-white/50')}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
