'use client';

import { AlertTriangle, RotateCcw } from 'lucide-react';
import Link from 'next/link';

interface Props {
  title?: string;
  message: string;
  onRetry?: () => void;
  retryHref?: string;
}

export function ErrorState({ title = 'تعذّر تحميل المحتوى', message, onRetry, retryHref }: Props) {
  return (
    <div role="alert" className="glass mx-auto flex max-w-xl flex-col items-center gap-3 rounded-2xl border-rose-400/20 px-6 py-10 text-center">
      <span className="grid h-14 w-14 place-items-center rounded-full bg-rose-500/15 text-rose-400">
        <AlertTriangle className="h-7 w-7" />
      </span>
      <h3 className="text-lg font-bold">{title}</h3>
      <p className="max-w-md text-sm leading-relaxed text-muted">{message}</p>
      {onRetry && (
        <button type="button" onClick={onRetry} className="btn-primary mt-2">
          <RotateCcw className="h-4 w-4" /> إعادة المحاولة
        </button>
      )}
      {!onRetry && retryHref && (
        <Link href={retryHref} className="btn-primary mt-2" prefetch={false}>
          <RotateCcw className="h-4 w-4" /> إعادة المحاولة
        </Link>
      )}
    </div>
  );
}
