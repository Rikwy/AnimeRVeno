'use client';

import { Bell, BellRing, Heart } from 'lucide-react';
import { cn } from '@/lib/utils';
import { favoritesStore, followingStore, toSaved, useSaved } from '@/lib/saved-store';
import type { AnimeSummary } from '@/lib/types';

interface Props {
  anime: AnimeSummary;
  variant?: 'icon' | 'full';
  className?: string;
}

export function FavoriteButton({ anime, variant = 'full', className }: Props) {
  const active = useSaved(favoritesStore).some((x) => x.id === anime.id);
  const toggle = () => favoritesStore.toggle(toSaved(anime));

  if (variant === 'icon') {
    return (
      <button
        type="button"
        onClick={toggle}
        aria-pressed={active}
        aria-label={active ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
        className={cn(
          'glass grid h-9 w-9 place-items-center rounded-full transition hover:scale-105',
          active ? 'text-rose-400' : 'text-fg',
          className,
        )}
      >
        <Heart className={cn('h-4 w-4', active && 'fill-rose-400')} />
      </button>
    );
  }
  return (
    <button type="button" onClick={toggle} aria-pressed={active} className={cn('btn-glass', active && 'border-rose-400/50', className)}>
      <Heart className={cn('h-4 w-4', active ? 'fill-rose-400 text-rose-400' : '')} />
      {active ? 'في المفضلة' : 'أضف إلى المفضلة'}
    </button>
  );
}

export function FollowButton({ anime, className }: { anime: AnimeSummary; className?: string }) {
  const active = useSaved(followingStore).some((x) => x.id === anime.id);
  const Icon = active ? BellRing : Bell;
  return (
    <button
      type="button"
      onClick={() => followingStore.toggle(toSaved(anime))}
      aria-pressed={active}
      className={cn('btn-glass', active && 'border-accent/60 text-accent', className)}
    >
      <Icon className="h-4 w-4" />
      {active ? 'تتابع هذا الأنمي' : 'متابعة الأنمي'}
    </button>
  );
}
