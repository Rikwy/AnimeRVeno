'use client';

import { Loader2, Search } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { FORMAT_AR } from '@/lib/constants';
import { useAnimeSearch } from '@/hooks/useAnimeSearch';
import { useDebouncedValue } from '@/hooks/useDebouncedValue';
import { getTitle } from '@/lib/utils';

/** Compact search with live suggestions (used in the navbar). Enter opens the full search page. */
export function SearchBar({ onNavigate }: { onNavigate?: () => void }) {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const debounced = useDebouncedValue(query, 300);
  const { items, loading, error } = useAnimeSearch(debounced, 6);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (!boxRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;
    setOpen(false);
    onNavigate?.();
    router.push(`/search?q=${encodeURIComponent(q)}`);
  };

  const showPanel = open && query.trim().length >= 2;

  return (
    <div ref={boxRef} className="relative w-full">
      <form onSubmit={submit} role="search">
        <label htmlFor="nav-search" className="sr-only">ابحث عن أنمي</label>
        <Search className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
        <input
          id="nav-search"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => e.key === 'Escape' && setOpen(false)}
          placeholder="ابحث عن أنمي…"
          autoComplete="off"
          className="field ps-9"
        />
        {loading && <Loader2 className="absolute end-3 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-muted" />}
      </form>

      {showPanel && (
        <div className="glass-strong absolute inset-x-0 top-full z-50 mt-2 max-h-96 overflow-y-auto rounded-2xl p-2">
          {error && <p className="p-3 text-sm text-rose-300">{error}</p>}
          {!error && !loading && items.length === 0 && debounced.trim().length >= 2 && (
            <p className="p-3 text-sm text-muted">لا توجد نتائج مطابقة.</p>
          )}
          {items.map((a) => (
            <Link
              key={a.id}
              href={`/anime/${a.id}`}
              onClick={() => {
                setOpen(false);
                onNavigate?.();
              }}
              className="flex items-center gap-3 rounded-xl p-2 transition hover:bg-white/10"
            >
              <span className="relative h-14 w-10 shrink-0 overflow-hidden rounded-md bg-surface">
                {a.coverImage.large && <Image src={a.coverImage.large} alt="" fill sizes="40px" className="object-cover" />}
              </span>
              <span className="min-w-0">
                <span dir="auto" className="block truncate text-sm font-medium">{getTitle(a.title)}</span>
                <span className="block text-xs text-muted">
                  {[a.seasonYear, a.format ? FORMAT_AR[a.format] ?? a.format : null].filter(Boolean).join(' • ')}
                </span>
              </span>
            </Link>
          ))}
          {items.length > 0 && (
            <Link
              href={`/search?q=${encodeURIComponent(query.trim())}`}
              onClick={() => setOpen(false)}
              className="mt-1 block rounded-xl p-2 text-center text-sm text-accent hover:bg-white/10"
            >
              عرض كل النتائج
            </Link>
          )}
        </div>
      )}
    </div>
  );
}
