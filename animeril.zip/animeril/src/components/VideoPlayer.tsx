'use client';

import { Film, Loader2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { ServerSource } from '@/lib/providers/types';
import { ErrorState } from './ErrorState';

interface Props {
  status: 'loading' | 'ready' | 'error';
  source: ServerSource | null;
  title: string;
  emptyMessage?: string;
  onRetry: () => void;
}

/**
 * Embeds an already-validated player URL (e.g. Ezv Player) in a sandboxed iframe.
 * URLs are allow-listed server-side (/api/episodes) and enforced by CSP frame-src (next.config.mjs).
 */
export function VideoPlayer({ status, source, title, emptyMessage, onRetry }: Props) {
  const [frameLoading, setFrameLoading] = useState(true);
  const [frameStuck, setFrameStuck] = useState(false);

  useEffect(() => {
    setFrameLoading(true);
    setFrameStuck(false);
    if (!source) return;
    const t = setTimeout(() => setFrameStuck(true), 15000);
    return () => clearTimeout(t);
  }, [source]);

  if (status === 'error') {
    return <ErrorState title="تعذّر تحميل السيرفرات" message="حدث خطأ أثناء جلب مصادر هذه الحلقة." onRetry={onRetry} />;
  }

  return (
    <div className="glass relative aspect-video w-full overflow-hidden rounded-2xl bg-black">
      {status === 'loading' && (
        <div className="absolute inset-0 grid place-items-center" role="status">
          <span className="flex items-center gap-2 text-sm text-muted">
            <Loader2 className="h-5 w-5 animate-spin" /> جارٍ تحميل السيرفرات…
          </span>
        </div>
      )}

      {status === 'ready' && !source && (
        <div className="absolute inset-0 grid place-items-center p-6 text-center">
          <div className="space-y-2">
            <Film className="mx-auto h-10 w-10 text-primary" />
            <p className="font-semibold">لا يتوفر مصدر تشغيل لهذه الحلقة</p>
            {emptyMessage && <p className="mx-auto max-w-md text-sm text-muted">{emptyMessage}</p>}
          </div>
        </div>
      )}

      {status === 'ready' && source && (
        <>
          <iframe
            key={source.url}
            src={source.url}
            title={title}
            className="h-full w-full"
            allow="fullscreen; picture-in-picture; autoplay; encrypted-media"
            allowFullScreen
            referrerPolicy="no-referrer"
            sandbox="allow-scripts allow-same-origin allow-presentation"
            onLoad={() => setFrameLoading(false)}
          />
          {frameLoading && (
            <div className="pointer-events-none absolute inset-0 grid place-items-center bg-black/60">
              <span className="flex items-center gap-2 text-sm text-muted">
                <Loader2 className="h-5 w-5 animate-spin" />
                {frameStuck ? 'التحميل يستغرق وقتاً أطول من المعتاد، جرّب سيرفراً آخر.' : 'جارٍ تحميل المشغل…'}
              </span>
            </div>
          )}
        </>
      )}
    </div>
  );
}
