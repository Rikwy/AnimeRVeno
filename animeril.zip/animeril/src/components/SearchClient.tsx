'use client';

import { Search, SearchX } from 'lucide-react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useAnimeSearch } from '@/hooks/useAnimeSearch';
import { useDebouncedValue } from '@/hooks/useDebouncedValue';
import { AnimeCard } from './AnimeCard';
import { EmptyState } from './EmptyState';
import { ErrorState } from './ErrorState';
import { GridSkeleton } from './LoadingSkeleton';

export function SearchClient() {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const [query, setQuery] = useState(sp.get('q') ?? '');
  const debounced = useDebouncedValue(query, 350);
  const { items, loading, error } = useAnimeSearch(debounced, 30);

  useEffect(() => {
    const q = debounced.trim();
    router.replace(q ? `${pathname}?q=${encodeURIComponent(q)}` : pathname, { scroll: false });
  }, [debounced, pathname, router]);

  const tooShort = debounced.trim().length < 2;

  return (
    <div className="space-y-6">
      <div className="glass relative rounded-2xl p-3">
        <label htmlFor="search-page-q" className="sr-only">ابحث عن أنمي</label>
        <Search className="pointer-events-none absolute start-6 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
        <input
          id="search-page-q"
          type="search"
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="اكتب اسم الأنمي بالإنجليزية أو اليابانية…"
          autoComplete="off"
          className="field ps-11 text-base"
        />
      </div>

      {tooShort && !loading && (
        <EmptyState icon={Search} title="ابدأ الكتابة للبحث" description="تظهر النتائج مباشرة أثناء الكتابة (حرفان على الأقل)." />
      )}
      {loading && <GridSkeleton count={10} />}
      {!loading && error && <ErrorState message={error} onRetry={() => setQuery((q) => q + ' ')} />}
      {!loading && !error && !tooShort && items.length === 0 && (
        <EmptyState icon={SearchX} title="لا توجد نتائج" description={`لم نجد أنمي مطابقاً لـ «${debounced.trim()}». جرّب كتابة الاسم بطريقة أخرى.`} action={{ label: 'استكشاف المكتبة', href: '/browse' }} />
      )}
      {!loading && items.length > 0 && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {items.map((a) => (
            <AnimeCard key={a.id} anime={a} />
          ))}
        </div>
      )}
    </div>
  );
}
