import { ChevronLeft } from 'lucide-react';
import Link from 'next/link';

export function SectionHeader({ title, href }: { title: string; href?: string }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <h2 className="text-xl font-bold sm:text-2xl">{title}</h2>
      {href && (
        <Link href={href} className="inline-flex items-center gap-1 text-sm text-muted transition hover:text-accent">
          عرض المزيد <ChevronLeft className="h-4 w-4" />
        </Link>
      )}
    </div>
  );
}
