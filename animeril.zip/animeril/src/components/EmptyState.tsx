import type { LucideIcon } from 'lucide-react';
import { Inbox } from 'lucide-react';
import Link from 'next/link';

interface Props {
  title: string;
  description?: string;
  icon?: LucideIcon;
  action?: { label: string; href: string };
}

export function EmptyState({ title, description, icon: Icon = Inbox, action }: Props) {
  return (
    <div className="glass mx-auto flex max-w-xl flex-col items-center gap-3 rounded-2xl px-6 py-12 text-center">
      <span className="grid h-14 w-14 place-items-center rounded-full bg-primary/15 text-primary">
        <Icon className="h-7 w-7" />
      </span>
      <h3 className="text-lg font-bold">{title}</h3>
      {description && <p className="max-w-md text-sm leading-relaxed text-muted">{description}</p>}
      {action && (
        <Link href={action.href} className="btn-primary mt-2">
          {action.label}
        </Link>
      )}
    </div>
  );
}
