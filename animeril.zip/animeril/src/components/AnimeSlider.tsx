'use client';

import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef } from 'react';
import type { AnimeSummary } from '@/lib/types';
import { AnimeCard } from './AnimeCard';

/** Horizontally scrollable row (touch-scroll on mobile, arrow buttons on larger screens). Layout is RTL. */
export function AnimeSlider({ items }: { items: AnimeSummary[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: 1 | -1) => {
    const el = ref.current;
    if (!el) return;
    // In RTL, "forward" means scrolling toward negative X.
    el.scrollBy({ left: -dir * el.clientWidth * 0.85, behavior: 'smooth' });
  };

  return (
    <div className="group/slider relative">
      <div ref={ref} className="no-scrollbar -mx-4 flex snap-x gap-4 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6 lg:mx-0 lg:px-0">
        {items.map((a) => (
          <div key={a.id} className="w-36 shrink-0 snap-start sm:w-40 md:w-44">
            <AnimeCard anime={a} />
          </div>
        ))}
      </div>
      <button
        type="button"
        onClick={() => scroll(-1)}
        aria-label="السابق"
        className="glass-strong absolute -end-3 top-1/3 z-10 hidden h-10 w-10 place-items-center rounded-full opacity-0 transition group-hover/slider:opacity-100 focus-visible:opacity-100 lg:grid"
      >
        <ChevronRight className="h-5 w-5" />
      </button>
      <button
        type="button"
        onClick={() => scroll(1)}
        aria-label="التالي"
        className="glass-strong absolute -start-3 top-1/3 z-10 hidden h-10 w-10 place-items-center rounded-full opacity-0 transition group-hover/slider:opacity-100 focus-visible:opacity-100 lg:grid"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
    </div>
  );
}
