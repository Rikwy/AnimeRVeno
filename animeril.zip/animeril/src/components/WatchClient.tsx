'use client';

import { ChevronLeft, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import type { ServerSource } from '@/lib/providers/types';
import { cn } from '@/lib/utils';
import { ServerSelector } from './ServerSelector';
import { VideoPlayer } from './VideoPlayer';

interface EpisodesResponse {
  servers: ServerSource[];
  providers: { id: string; name: string; configured: boolean; ok: boolean }[];
  rejected: number;
  embedHostsConfigured: boolean;
}

interface Props {
  animeId: number;
  episode: number;
  total: number;
  title: string;
}

function emptyHint(d: EpisodesResponse): string {
  if (!d.providers.some((p) => p.configured)) return 'لم يُربط أي مصدر حلقات بعد. يضبطه مالك الموقع من متغيرات البيئة (راجع README).';
  if (d.providers.some((p) => p.configured && !p.ok)) return 'تعذّر الوصول إلى مصدر الحلقات حالياً. حاول لاحقاً.';
  if (d.rejected > 0 && !d.embedHostsConfigured) return 'تم رفض روابط التشغيل لأن ALLOWED_EMBED_HOSTS غير مضبوط.';
  if (d.rejected > 0) return 'تم استبعاد روابط تشغيل غير موثوقة.';
  return 'لم يجد المصدر سيرفرات لهذه الحلقة بعد.';
}

export function WatchClient({ animeId, episode, total, title }: Props) {
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [data, setData] = useState<EpisodesResponse | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    const ctrl = new AbortController();
    setStatus('loading');
    setData(null);
    setSelected(null);
    fetch(`/api/episodes?animeId=${animeId}&episode=${episode}`, { signal: ctrl.signal, cache: 'no-store' })
      .then((r) => {
        if (!r.ok) throw new Error('bad response');
        return r.json() as Promise<EpisodesResponse>;
      })
      .then((d) => {
        setData(d);
        setSelected(d.servers[0]?.id ?? null);
        setStatus('ready');
      })
      .catch((e: unknown) => {
        if (e instanceof DOMException && e.name === 'AbortError') return;
        setStatus('error');
      });
    return () => ctrl.abort();
  }, [animeId, episode, attempt]);

  const source = data?.servers.find((s) => s.id === selected) ?? null;
  const prev = episode > 1 ? `/watch/${animeId}/${episode - 1}` : null;
  const next = episode < total ? `/watch/${animeId}/${episode + 1}` : null;

  const navBtn = (href: string | null, label: string, icon: React.ReactNode, iconFirst: boolean) =>
    href ? (
      <Link href={href} className="btn-glass">
        {iconFirst && icon}
        {label}
        {!iconFirst && icon}
      </Link>
    ) : (
      <span aria-disabled="true" className={cn('btn-glass pointer-events-none opacity-40')}>
        {iconFirst && icon}
        {label}
        {!iconFirst && icon}
      </span>
    );

  return (
    <div className="space-y-4">
      <VideoPlayer
        status={status}
        source={source}
        title={`${title} – الحلقة ${episode}`}
        emptyMessage={data ? emptyHint(data) : undefined}
        onRetry={() => setAttempt((a) => a + 1)}
      />
      <div className="flex flex-wrap items-center justify-between gap-3">
        {navBtn(prev, 'الحلقة السابقة', <ChevronRight className="h-4 w-4" />, true)}
        <span className="text-sm text-muted">الحلقة {episode} من {total}</span>
        {navBtn(next, 'الحلقة التالية', <ChevronLeft className="h-4 w-4" />, false)}
      </div>
      {data && data.servers.length > 0 && (
        <div className="glass space-y-3 rounded-2xl p-4">
          <h2 className="text-sm font-semibold">السيرفرات</h2>
          <ServerSelector servers={data.servers} selectedId={selected} onSelect={setSelected} />
        </div>
      )}
    </div>
  );
}
