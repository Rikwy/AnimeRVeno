'use client';

import { SearchX } from 'lucide-react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { AnimeSummary } from '@/lib/types';
import { AnimeCard } from './AnimeCard';
import { EmptyState } from './EmptyState';
import { ErrorState } from './ErrorState';
import { FilterPanel, type Filters } from './FilterPanel';
import { GridSkeleton } from './LoadingSkeleton';

export function BrowseClient() {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const query = sp.toString();

  const filters: Filters = {
    q: sp.get('q') ?? '',
    genre: sp.get('genre') ?? '',
    year: sp.get('year') ?? '',
    status: sp.get('status') ?? '',
    season: sp.get('season') ?? '',
    sort: sp.get('sort') ?? '',
  };

  const update = (patch: Partial<Filters>) => {
    const p = new URLSearchParams(sp.toString());
    Object.entries(patch).forEach(([k, v]) => (v ? p.set(k, v) : p.delete(k)));
    // AniList's season filter works together with a year: default to the current year.
    if (patch.season && !p.get('year')) p.set('year', String(new Date().getFullYear()));
    const qs = p.toString();
    router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
  };

  const [items, setItems] = useState<AnimeSummary[]>([]);
  const [page, setPage] = useState(1);
  const [hasNext, setHasNext] = useState(false);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');
  const [moreLoading, setMoreLoading] = useState(false);
  const [moreError, setMoreError] = useState(false);
  const reqId = useRef(0);
  const sentinel = useRef<HTMLDivElement>(null);

  const load = useCallback(
    async (p: number) => {
      const id = ++reqId.current;
      if (p === 1) {
        setStatus('loading');
        setItems([]);
      } else {
        setMoreLoading(true);
        setMoreError(false);
      }
      try {
        const res = await fetch(`/api/anime?${query}&page=${p}`);
        const json = await res.json();
        if (id !== reqId.current) return;
        if (!res.ok) throw new Error(json.error ?? 'تعذّر تحميل البيانات');
        setItems((prev) => {
          const seen = new Set(prev.map((x) => x.id));
          return p === 1 ? json.items : [...prev, ...(json.items as AnimeSummary[]).filter((x) => !seen.has(x.id))];
        });
        setHasNext(json.hasNextPage);
        setPage(p);
        setStatus('ready');
      } catch (e) {
        if (id !== reqId.current) return;
        if (p === 1) {
          setError(e instanceof Error ? e.message : 'تعذّر تحميل البيانات');
          setStatus('error');
        } else {
          setMoreError(true);
        }
      } finally {
        if (id === reqId.current) setMoreLoading(false);
      }
    },
    [query],
  );

  useEffect(() => {
    load(1);
  }, [load]);

  // Infinite scroll
  useEffect(() => {
    const el = sentinel.current;
    if (!el || !hasNext || moreLoading || moreError || status !== 'ready') return;
    const obs = new IntersectionObserver((entries) => entries[0].isIntersecting && load(page + 1), { rootMargin: '400px' });
    obs.observe(el);
    return () => obs.disconnect();
  }, [hasNext, moreLoading, moreError, status, page, load]);

  return (
    <div className="space-y-6">
      <FilterPanel value={filters} onChange={update} onReset={() => router.replace(pathname, { scroll: false })} />

      {status === 'loading' && <GridSkeleton />}
      {status === 'error' && <ErrorState message={error} onRetry={() => load(1)} />}
      {status === 'ready' && items.length === 0 && (
        <EmptyState icon={SearchX} title="لا توجد نتائج" description="جرّب تغيير الفلاتر أو البحث بكلمة مختلفة." action={{ label: 'إعادة ضبط الفلاتر', href: pathname }} />
      )}
      {items.length > 0 && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {items.map((a, i) => (
            <AnimeCard key={a.id} anime={a} priority={i < 6} />
          ))}
        </div>
      )}
      {status === 'ready' && hasNext && (
        <div ref={sentinel} className="flex justify-center py-6">
          {moreError ? (
            <button type="button" className="btn-glass" onClick={() => load(page + 1)}>
              فشل تحميل المزيد — أعد المحاولة
            </button>
          ) : (
            <button type="button" className="btn-glass" disabled={moreLoading} onClick={() => load(page + 1)}>
              {moreLoading ? 'جارٍ التحميل…' : 'تحميل المزيد'}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
