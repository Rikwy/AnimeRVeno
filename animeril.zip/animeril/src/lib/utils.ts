import clsx, { type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { AnimeTitle } from './types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Display title: English → Romaji → Native. */
export function getTitle(t: AnimeTitle): string {
  return t.english || t.romaji || t.native || 'بدون عنوان';
}

/** AniList returns HTML-ish descriptions. We reduce to plain text and render it as text (never as HTML). */
export function cleanDescription(html?: string | null): string {
  if (!html) return '';
  return html
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export function formatScore(score: number | null | undefined): string | null {
  return typeof score === 'number' ? (score / 10).toFixed(1) : null;
}

export function errorMessage(e: unknown): string {
  return e instanceof Error ? e.message : 'حدث خطأ غير متوقع';
}

export function currentSeason(date = new Date()): { season: 'WINTER' | 'SPRING' | 'SUMMER' | 'FALL'; year: number } {
  const m = date.getMonth();
  const season = m <= 2 ? 'WINTER' : m <= 5 ? 'SPRING' : m <= 8 ? 'SUMMER' : 'FALL';
  return { season, year: date.getFullYear() };
}
