export type MediaStatus = 'FINISHED' | 'RELEASING' | 'NOT_YET_RELEASED' | 'CANCELLED' | 'HIATUS';
export type MediaSeason = 'WINTER' | 'SPRING' | 'SUMMER' | 'FALL';
export type MediaSort =
  | 'POPULARITY_DESC'
  | 'SCORE_DESC'
  | 'START_DATE_DESC'
  | 'TRENDING_DESC'
  | 'UPDATED_AT_DESC'
  | 'SEARCH_MATCH';

export interface AnimeTitle {
  romaji: string | null;
  english: string | null;
  native: string | null;
}

export interface AnimeSummary {
  id: number;
  title: AnimeTitle;
  coverImage: { large: string | null; extraLarge: string | null; color: string | null };
  bannerImage: string | null;
  averageScore: number | null;
  seasonYear: number | null;
  format: string | null;
  status: MediaStatus | null;
  episodes: number | null;
  genres: string[];
  description?: string | null;
}

export interface CharacterEdge {
  role: string;
  node: { id: number; name: { full: string | null; native: string | null }; image: { large: string | null } };
}

export interface StaffEdge {
  role: string | null;
  node: { id: number; name: { full: string | null }; image: { medium: string | null } };
}

export interface AnimeDetail extends AnimeSummary {
  synonyms: string[];
  arabicTitle: string | null;
  duration: number | null;
  season: MediaSeason | null;
  studios: string[];
  nextAiringEpisode: { episode: number; airingAt: number } | null;
  characters: CharacterEdge[];
  staff: StaffEdge[];
}

export interface PageResult<T> {
  items: T[];
  hasNextPage: boolean;
  currentPage: number;
}

export interface BrowseParams {
  search?: string;
  genre?: string;
  year?: number;
  status?: MediaStatus;
  season?: MediaSeason;
  sort?: MediaSort;
  page?: number;
  perPage?: number;
}
