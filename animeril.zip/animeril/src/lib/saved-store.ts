'use client';

import { useSyncExternalStore } from 'react';
import type { AnimeSummary } from './types';
import { getTitle } from './utils';

export interface SavedAnime {
  id: number;
  title: string;
  cover: string | null;
  score: number | null;
  year: number | null;
  format: string | null;
  addedAt: number;
}

export const EMPTY_LIST: SavedAnime[] = [];

export function toSaved(a: AnimeSummary): SavedAnime {
  return {
    id: a.id,
    title: getTitle(a.title),
    cover: a.coverImage.extraLarge ?? a.coverImage.large,
    score: a.averageScore,
    year: a.seasonYear,
    format: a.format,
    addedAt: Date.now(),
  };
}

function createStore(key: string) {
  let cache: { raw: string | null; value: SavedAnime[] } = { raw: null, value: EMPTY_LIST };
  const listeners = new Set<() => void>();

  function getSnapshot(): SavedAnime[] {
    let raw: string | null = null;
    try {
      raw = localStorage.getItem(key);
    } catch {
      return EMPTY_LIST;
    }
    if (raw === null) return EMPTY_LIST;
    if (raw === cache.raw) return cache.value;
    let value = EMPTY_LIST;
    try {
      const parsed: unknown = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        value = parsed.filter((x): x is SavedAnime => !!x && typeof (x as SavedAnime).id === 'number');
      }
    } catch {
      /* corrupted storage → treat as empty */
    }
    cache = { raw, value };
    return value;
  }

  function write(list: SavedAnime[]) {
    try {
      localStorage.setItem(key, JSON.stringify(list));
    } catch {
      /* storage full or blocked */
    }
    listeners.forEach((l) => l());
  }

  return {
    getSnapshot,
    getServerSnapshot: () => EMPTY_LIST,
    subscribe(cb: () => void) {
      listeners.add(cb);
      const onStorage = (e: StorageEvent) => e.key === key && cb();
      window.addEventListener('storage', onStorage);
      return () => {
        listeners.delete(cb);
        window.removeEventListener('storage', onStorage);
      };
    },
    toggle(item: SavedAnime) {
      const list = getSnapshot();
      write(list.some((x) => x.id === item.id) ? list.filter((x) => x.id !== item.id) : [item, ...list]);
    },
    remove(id: number) {
      write(getSnapshot().filter((x) => x.id !== id));
    },
  };
}

export const favoritesStore = createStore('animeril:favorites');
export const followingStore = createStore('animeril:following');

export function useSaved(store: ReturnType<typeof createStore>): SavedAnime[] {
  return useSyncExternalStore(store.subscribe, store.getSnapshot, store.getServerSnapshot);
}
