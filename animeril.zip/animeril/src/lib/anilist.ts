const ENDPOINT = process.env.ANILIST_ENDPOINT ?? 'https://graphql.anilist.co';

export class AniListError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = 'AniListError';
  }
}

/** Single entry point for AniList GraphQL calls (server-side only, cached via Next fetch cache). */
export async function anilist<T>(
  query: string,
  variables: Record<string, unknown> = {},
  revalidate = 600,
): Promise<T> {
  let res: Response;
  try {
    res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ query, variables }),
      next: { revalidate },
    });
  } catch {
    throw new AniListError('تعذّر الاتصال بخدمة AniList. تحقق من اتصالك وحاول مجدداً.');
  }
  if (res.status === 429) throw new AniListError('تم تجاوز حد الطلبات المسموح. حاول بعد دقيقة.', 429);
  const json = await res.json().catch(() => null);
  if (!res.ok || !json || json.errors?.length) {
    throw new AniListError(json?.errors?.[0]?.message ?? `خطأ من AniList (${res.status})`, res.status);
  }
  return json.data as T;
}
