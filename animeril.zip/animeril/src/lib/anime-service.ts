import { cache } from 'react';
import { anilist, AniListError } from './anilist';
import type { AnimeDetail, AnimeSummary, BrowseParams, MediaSort, PageResult } from './types';

const CARD = `
  id title { romaji english native }
  coverImage { large extraLarge color }
  bannerImage averageScore seasonYear format status episodes genres
`;

const PAGE_QUERY = `
query ($page: Int, $perPage: Int, $search: String, $genre: String, $seasonYear: Int,
       $season: MediaSeason, $status: MediaStatus, $sort: [MediaSort]) {
  Page(page: $page, perPage: $perPage) {
    pageInfo { hasNextPage currentPage }
    media(type: ANIME, isAdult: false, search: $search, genre: $genre, seasonYear: $seasonYear,
          season: $season, status: $status, sort: $sort) { ${CARD} }
  }
}`;

interface PageResponse {
  Page: { pageInfo: { hasNextPage: boolean; currentPage: number }; media: AnimeSummary[] };
}

export async function fetchPage(params: BrowseParams, revalidate = 600): Promise<PageResult<AnimeSummary>> {
  const sort: MediaSort = params.sort ?? (params.search ? 'SEARCH_MATCH' : 'POPULARITY_DESC');
  const data = await anilist<PageResponse>(
    PAGE_QUERY,
    {
      page: params.page ?? 1,
      perPage: params.perPage ?? 24,
      search: params.search || undefined,
      genre: params.genre || undefined,
      seasonYear: params.year,
      season: params.season,
      status: params.status,
      sort: [sort],
    },
    revalidate,
  );
  return {
    items: data.Page.media,
    hasNextPage: data.Page.pageInfo.hasNextPage,
    currentPage: data.Page.pageInfo.currentPage,
  };
}

const HERO_QUERY = `
query {
  Page(page: 1, perPage: 12) {
    media(type: ANIME, isAdult: false, sort: TRENDING_DESC) { ${CARD} description(asHtml: false) }
  }
}`;

export async function getHeroItems(): Promise<AnimeSummary[]> {
  const data = await anilist<{ Page: { media: AnimeSummary[] } }>(HERO_QUERY);
  return data.Page.media.filter((m) => m.bannerImage).slice(0, 5);
}

const DETAIL_QUERY = `
query ($id: Int) {
  Media(id: $id, type: ANIME) {
    ${CARD}
    description(asHtml: false) synonyms duration season
    studios(isMain: true) { nodes { name } }
    nextAiringEpisode { episode airingAt }
    characters(role: MAIN, sort: [ROLE], perPage: 12) {
      edges { role node { id name { full native } image { large } } }
    }
    staff(perPage: 8) { edges { role node { id name { full } image { medium } } } }
  }
}`;

interface DetailRaw extends Omit<AnimeDetail, 'studios' | 'characters' | 'staff' | 'arabicTitle'> {
  studios: { nodes: { name: string }[] };
  characters: { edges: AnimeDetail['characters'] };
  staff: { edges: AnimeDetail['staff'] };
}

const ARABIC = /[\u0600-\u06FF]/;

/** Returns null when the anime does not exist. Deduplicated per request via React cache(). */
export const getAnimeDetail = cache(async (id: number): Promise<AnimeDetail | null> => {
  try {
    const data = await anilist<{ Media: DetailRaw | null }>(DETAIL_QUERY, { id }, 900);
    const m = data.Media;
    if (!m) return null;
    return {
      ...m,
      synonyms: m.synonyms ?? [],
      arabicTitle: (m.synonyms ?? []).find((s) => ARABIC.test(s)) ?? null,
      studios: m.studios.nodes.map((s) => s.name),
      characters: m.characters.edges,
      staff: m.staff.edges,
    };
  } catch (e) {
    if (e instanceof AniListError && e.status === 404) return null;
    throw e;
  }
});

/** Number of episodes that have actually aired (from AniList). */
export function getAiredEpisodes(a: Pick<AnimeDetail, 'episodes' | 'nextAiringEpisode' | 'status'>): number {
  if (a.status === 'NOT_YET_RELEASED') return 0;
  if (a.nextAiringEpisode) return Math.max(0, a.nextAiringEpisode.episode - 1);
  return a.episodes ?? 0;
}
