import { anime3rbProvider } from './anime3rb';
import type { EpisodeProvider } from './types';

/** Register additional episode sources here. */
export const providers: EpisodeProvider[] = [anime3rbProvider];
