import { parseServers } from './parse';
import type { EpisodeProvider } from './types';

/**
 * Anime3rb adapter.
 *
 * Anime3rb does not publish an official public API that we know of, and this project does NOT scrape
 * the site. Point ANIME3RB_API_BASE at an endpoint you are AUTHORIZED to use that follows this contract:
 *
 *   GET {BASE}/servers?anilistId=<id>&episode=<n>
 *   -> 200 { "servers": [ { "name": "string", "url": "https://...", "quality": "720p" } ] }
 *
 * Until it is configured, the provider reports "not configured" and returns nothing.
 */
export const anime3rbProvider: EpisodeProvider = {
  id: 'anime3rb',
  name: 'Anime3rb',
  isConfigured: () => Boolean(process.env.ANIME3RB_API_BASE),
  async getServers({ animeId, episode }) {
    const base = process.env.ANIME3RB_API_BASE;
    if (!base) return [];
    const url = new URL('servers', base.endsWith('/') ? base : `${base}/`);
    url.searchParams.set('anilistId', String(animeId));
    url.searchParams.set('episode', String(episode));
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (process.env.ANIME3RB_API_KEY) headers.Authorization = `Bearer ${process.env.ANIME3RB_API_KEY}`;
    const res = await fetch(url, { headers, signal: AbortSignal.timeout(8000), next: { revalidate: 60 } });
    if (!res.ok) throw new Error(`Anime3rb responded ${res.status}`);
    return parseServers(await res.json(), 'anime3rb');
  },
};
