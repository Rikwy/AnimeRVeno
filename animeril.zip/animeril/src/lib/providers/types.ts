export interface EpisodeContext {
  /** AniList media id */
  animeId: number;
  episode: number;
}

export interface ServerSource {
  id: string;
  providerId: string;
  name: string;
  /** Embeddable player URL. Validated against ALLOWED_EMBED_HOSTS before reaching the client. */
  url: string;
  quality?: string;
}

/**
 * Add a new episode source by implementing this interface and registering it
 * in providers/registry.ts. No other file needs to change.
 */
export interface EpisodeProvider {
  id: string;
  name: string;
  isConfigured(): boolean;
  getServers(ctx: EpisodeContext): Promise<ServerSource[]>;
}
