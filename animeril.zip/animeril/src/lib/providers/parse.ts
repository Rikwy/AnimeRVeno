import type { ServerSource } from './types';

/** Parses the JSON contract `{ servers: [{ name, url, quality? }] }` defensively. */
export function parseServers(data: unknown, providerId: string): ServerSource[] {
  const list = (data as { servers?: unknown } | null)?.servers;
  if (!Array.isArray(list)) throw new Error('استجابة غير صالحة من مصدر الحلقات');
  const out: ServerSource[] = [];
  list.forEach((raw, i) => {
    if (!raw || typeof raw !== 'object') return;
    const r = raw as Record<string, unknown>;
    if (typeof r.url !== 'string') return;
    out.push({
      id: `${providerId}:${i}`,
      providerId,
      name: typeof r.name === 'string' && r.name ? r.name.slice(0, 40) : `سيرفر ${i + 1}`,
      url: r.url,
      quality: typeof r.quality === 'string' ? r.quality.slice(0, 12) : undefined,
    });
  });
  return out;
}
