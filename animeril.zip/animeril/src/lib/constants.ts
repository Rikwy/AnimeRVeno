export const GENRES = [
  ['Action', 'أكشن'], ['Adventure', 'مغامرة'], ['Comedy', 'كوميدي'], ['Drama', 'دراما'],
  ['Ecchi', 'إيتشي'], ['Fantasy', 'فانتازيا'], ['Horror', 'رعب'], ['Mahou Shoujo', 'فتيات سحريات'],
  ['Mecha', 'ميكا'], ['Music', 'موسيقى'], ['Mystery', 'غموض'], ['Psychological', 'نفسي'],
  ['Romance', 'رومانسي'], ['Sci-Fi', 'خيال علمي'], ['Slice of Life', 'شريحة من الحياة'],
  ['Sports', 'رياضة'], ['Supernatural', 'خارق للطبيعة'], ['Thriller', 'إثارة'],
] as const;

export const GENRE_AR: Record<string, string> = Object.fromEntries(GENRES);

export const STATUS_AR: Record<string, string> = {
  FINISHED: 'مكتمل',
  RELEASING: 'يُعرض حالياً',
  NOT_YET_RELEASED: 'لم يُعرض بعد',
  CANCELLED: 'ملغي',
  HIATUS: 'متوقف مؤقتاً',
};

export const FORMAT_AR: Record<string, string> = {
  TV: 'مسلسل',
  TV_SHORT: 'مسلسل قصير',
  MOVIE: 'فيلم',
  SPECIAL: 'حلقة خاصة',
  OVA: 'OVA',
  ONA: 'ONA',
  MUSIC: 'موسيقي',
};

export const SEASON_AR: Record<string, string> = {
  WINTER: 'الشتاء',
  SPRING: 'الربيع',
  SUMMER: 'الصيف',
  FALL: 'الخريف',
};

export const ROLE_AR: Record<string, string> = { MAIN: 'رئيسية', SUPPORTING: 'داعمة', BACKGROUND: 'خلفية' };

export const SORT_OPTIONS = [
  { value: 'POPULARITY_DESC', label: 'الأكثر شعبية' },
  { value: 'SCORE_DESC', label: 'الأعلى تقييماً' },
  { value: 'START_DATE_DESC', label: 'الأحدث إصداراً' },
  { value: 'TRENDING_DESC', label: 'الرائج الآن' },
  { value: 'SEARCH_MATCH', label: 'الأكثر صلة بالبحث' },
] as const;

export const STATUS_VALUES = ['FINISHED', 'RELEASING', 'NOT_YET_RELEASED', 'CANCELLED', 'HIATUS'] as const;
export const SEASON_VALUES = ['WINTER', 'SPRING', 'SUMMER', 'FALL'] as const;
export const SORT_VALUES = SORT_OPTIONS.map((o) => o.value);

export function yearOptions(): number[] {
  const max = new Date().getFullYear() + 1;
  return Array.from({ length: max - 1979 }, (_, i) => max - i);
}
