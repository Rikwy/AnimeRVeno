export function getAllowedHosts(): string[] {
  return (process.env.ALLOWED_EMBED_HOSTS ?? '')
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

/** Only https URLs whose host (or parent domain) is explicitly allow-listed may be embedded. */
export function isAllowedEmbedUrl(raw: string, hosts: string[] = getAllowedHosts()): boolean {
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    return false;
  }
  if (u.protocol !== 'https:' || u.username || u.password) return false;
  const h = u.hostname.toLowerCase();
  return hosts.some((a) => h === a || h.endsWith(`.${a}`));
}
