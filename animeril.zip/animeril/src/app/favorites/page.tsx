import type { Metadata } from 'next';
import { FavoritesClient } from '@/components/FavoritesClient';

export const metadata: Metadata = { title: 'المفضلة' };

export default function FavoritesPage() {
  return (
    <div className="container-page py-8">
      <h1 className="mb-6 text-2xl font-extrabold sm:text-3xl">مكتبتي</h1>
      <FavoritesClient />
    </div>
  );
}
