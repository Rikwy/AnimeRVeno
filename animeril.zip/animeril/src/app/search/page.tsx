import type { Metadata } from 'next';
import { Suspense } from 'react';
import { SearchClient } from '@/components/SearchClient';

export const metadata: Metadata = { title: 'بحث' };

export default function SearchPage() {
  return (
    <div className="container-page py-8">
      <h1 className="mb-6 text-2xl font-extrabold sm:text-3xl">بحث</h1>
      <Suspense>
        <SearchClient />
      </Suspense>
    </div>
  );
}
