import { Suspense } from 'react';
import { AnimeSlider } from '@/components/AnimeSlider';
import { EmptyState } from '@/components/EmptyState';
import { ErrorState } from '@/components/ErrorState';
import { HeroBanner } from '@/components/HeroBanner';
import { SliderSkeleton } from '@/components/LoadingSkeleton';
import { SectionHeader } from '@/components/SectionHeader';
import { fetchPage, getHeroItems } from '@/lib/anime-service';
import { SEASON_AR } from '@/lib/constants';
import type { AnimeSummary, BrowseParams } from '@/lib/types';
import { currentSeason, errorMessage } from '@/lib/utils';

export const revalidate = 600;

async function Hero() {
  try {
    const items = await getHeroItems();
    if (items.length === 0) return <div className="h-8" />;
    return <HeroBanner items={items} />;
  } catch (e) {
    return (
      <div className="container-page pt-8">
        <ErrorState message={errorMessage(e)} retryHref="/" />
      </div>
    );
  }
}

async function Row({ title, href, params }: { title: string; href: string; params: BrowseParams }) {
  let items: AnimeSummary[];
  try {
    items = (await fetchPage({ perPage: 20, ...params })).items;
  } catch (e) {
    return (
      <section>
        <SectionHeader title={title} href={href} />
        <ErrorState title="تعذّر تحميل هذا القسم" message={errorMessage(e)} retryHref="/" />
      </section>
    );
  }
  return (
    <section>
      <SectionHeader title={title} href={href} />
      {items.length === 0 ? <EmptyState title="لا توجد نتائج في هذا القسم" /> : <AnimeSlider items={items} />}
    </section>
  );
}

function RowFallback({ title }: { title: string }) {
  return (
    <section>
      <SectionHeader title={title} />
      <SliderSkeleton />
    </section>
  );
}

export default function HomePage() {
  const { season, year } = currentSeason();
  const rows: { title: string; href: string; params: BrowseParams }[] = [
    { title: 'الأكثر شعبية', href: '/browse?sort=POPULARITY_DESC', params: { sort: 'POPULARITY_DESC' } },
    {
      title: `أنميات ${SEASON_AR[season]} ${year}`,
      href: `/browse?season=${season}&year=${year}`,
      params: { season, year, sort: 'POPULARITY_DESC' },
    },
    { title: 'الأنميات القادمة', href: '/browse?status=NOT_YET_RELEASED', params: { status: 'NOT_YET_RELEASED', sort: 'POPULARITY_DESC' } },
    { title: 'آخر الإضافات', href: '/browse?status=RELEASING', params: { status: 'RELEASING', sort: 'UPDATED_AT_DESC' } },
    { title: 'الأعلى تقييماً', href: '/browse?sort=SCORE_DESC', params: { sort: 'SCORE_DESC' } },
  ];

  return (
    <>
      <Suspense fallback={<div className="-mt-16 h-[520px] animate-pulse bg-surface/50 sm:h-[78vh]" />}>
        <Hero />
      </Suspense>
      <div className="container-page space-y-12 pt-10">
        {rows.map((r) => (
          <Suspense key={r.title} fallback={<RowFallback title={r.title} />}>
            <Row {...r} />
          </Suspense>
        ))}
      </div>
    </>
  );
}
