import type { Metadata } from 'next';
import { Suspense } from 'react';
import { BrowseClient } from '@/components/BrowseClient';
import { GridSkeleton } from '@/components/LoadingSkeleton';

export const metadata: Metadata = { title: 'استكشاف الأنمي' };

export default function BrowsePage() {
  return (
    <div className="container-page py-8">
      <h1 className="mb-6 text-2xl font-extrabold sm:text-3xl">استكشاف الأنمي</h1>
      <Suspense fallback={<GridSkeleton />}>
        <BrowseClient />
      </Suspense>
    </div>
  );
}
