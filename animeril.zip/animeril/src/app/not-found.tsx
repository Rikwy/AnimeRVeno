import { EmptyState } from '@/components/EmptyState';
import { SearchX } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="container-page py-20">
      <EmptyState icon={SearchX} title="الصفحة غير موجودة" description="الرابط الذي فتحته غير صحيح أو أن المحتوى لم يعد متاحاً." action={{ label: 'العودة للرئيسية', href: '/' }} />
    </div>
  );
}
