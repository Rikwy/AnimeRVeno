import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { EpisodeList } from '@/components/EpisodeList';
import { ErrorState } from '@/components/ErrorState';
import { SectionHeader } from '@/components/SectionHeader';
import { WatchClient } from '@/components/WatchClient';
import { getAiredEpisodes, getAnimeDetail } from '@/lib/anime-service';
import type { AnimeDetail } from '@/lib/types';
import { cleanDescription, errorMessage, getTitle } from '@/lib/utils';

export const revalidate = 300;

type Props = { params: { id: string; episode: string } };

function parse(raw: string): number | null {
  const n = Number(raw);
  return Number.isInteger(n) && n > 0 ? n : null;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const id = parse(params.id);
  if (!id) return { title: 'مشاهدة' };
  try {
    const a = await getAnimeDetail(id);
    return { title: a ? `${getTitle(a.title)} – الحلقة ${params.episode}` : 'مشاهدة' };
  } catch {
    return { title: 'مشاهدة' };
  }
}

export default async function WatchPage({ params }: Props) {
  const id = parse(params.id);
  const episode = parse(params.episode);
  if (!id || !episode) notFound();

  let anime: AnimeDetail | null;
  try {
    anime = await getAnimeDetail(id);
  } catch (e) {
    return (
      <div className="container-page py-16">
        <ErrorState message={errorMessage(e)} retryHref={`/watch/${id}/${episode}`} />
      </div>
    );
  }
  if (!anime) notFound();

  const total = getAiredEpisodes(anime);
  if (episode > total) notFound();
  const title = getTitle(anime.title);

  return (
    <div className="container-page py-6">
      <nav aria-label="مسار التنقل" className="mb-4 text-sm text-muted">
        <Link href="/" className="hover:text-fg">الرئيسية</Link> / <Link href={`/anime/${anime.id}`} className="hover:text-fg">{title}</Link> / الحلقة {episode}
      </nav>
      <h1 dir="auto" className="mb-4 text-xl font-extrabold sm:text-2xl">
        {title} <span className="text-gradient">– الحلقة {episode}</span>
      </h1>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <div className="space-y-6">
          <WatchClient animeId={anime.id} episode={episode} total={total} title={title} />
          <section className="glass rounded-2xl p-5">
            <h2 className="mb-2 font-bold">نبذة عن الأنمي</h2>
            <p className="line-clamp-5 whitespace-pre-line text-sm leading-loose text-fg/85">
              {cleanDescription(anime.description) || 'لا يتوفر وصف.'}
            </p>
            <Link href={`/anime/${anime.id}`} className="mt-3 inline-block text-sm text-accent hover:underline">
              كل التفاصيل
            </Link>
          </section>
        </div>
        <aside aria-label="قائمة الحلقات">
          <SectionHeader title="الحلقات" />
          <EpisodeList animeId={anime.id} total={total} current={episode} compact />
        </aside>
      </div>
    </div>
  );
}
