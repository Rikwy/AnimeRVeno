import { GridSkeleton } from '@/components/LoadingSkeleton';

export default function Loading() {
  return (
    <div className="container-page py-8">
      <GridSkeleton />
    </div>
  );
}
