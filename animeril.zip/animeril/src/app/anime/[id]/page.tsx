import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Calendar, Clapperboard, Clock, Film, Play } from 'lucide-react';
import { EmptyState } from '@/components/EmptyState';
import { EpisodeList } from '@/components/EpisodeList';
import { ErrorState } from '@/components/ErrorState';
import { FavoriteButton, FollowButton } from '@/components/FavoriteButton';
import { RatingBadge } from '@/components/RatingBadge';
import { SectionHeader } from '@/components/SectionHeader';
import { getAiredEpisodes, getAnimeDetail } from '@/lib/anime-service';
import { FORMAT_AR, GENRE_AR, ROLE_AR, SEASON_AR, STATUS_AR } from '@/lib/constants';
import type { AnimeDetail } from '@/lib/types';
import { cleanDescription, errorMessage, getTitle } from '@/lib/utils';

export const revalidate = 900;

type Props = { params: { id: string } };

function parseId(raw: string): number | null {
  const n = Number(raw);
  return Number.isInteger(n) && n > 0 ? n : null;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const id = parseId(params.id);
  if (!id) return { title: 'غير موجود' };
  try {
    const a = await getAnimeDetail(id);
    return a ? { title: getTitle(a.title), description: cleanDescription(a.description).slice(0, 160) } : { title: 'غير موجود' };
  } catch {
    return { title: 'أنمي' };
  }
}

export default async function AnimeDetailsPage({ params }: Props) {
  const id = parseId(params.id);
  if (!id) notFound();

  let anime: AnimeDetail | null;
  try {
    anime = await getAnimeDetail(id);
  } catch (e) {
    return (
      <div className="container-page py-16">
        <ErrorState message={errorMessage(e)} retryHref={`/anime/${id}`} />
      </div>
    );
  }
  if (!anime) notFound();

  const title = getTitle(anime.title);
  const cover = anime.coverImage.extraLarge ?? anime.coverImage.large;
  const aired = getAiredEpisodes(anime);
  const otherTitles = [
    anime.arabicTitle,
    anime.title.native,
    anime.title.romaji !== title ? anime.title.romaji : null,
  ].filter((t): t is string => Boolean(t));

  const facts = [
    { icon: Calendar, label: 'السنة', value: anime.seasonYear ? `${anime.seasonYear}${anime.season ? ` – ${SEASON_AR[anime.season]}` : ''}` : null },
    { icon: Clapperboard, label: 'الحالة', value: anime.status ? STATUS_AR[anime.status] : null },
    { icon: Film, label: 'النوع', value: anime.format ? FORMAT_AR[anime.format] ?? anime.format : null },
    { icon: Play, label: 'الحلقات', value: anime.episodes ? String(anime.episodes) : aired ? `${aired} حتى الآن` : null },
    { icon: Clock, label: 'مدة الحلقة', value: anime.duration ? `${anime.duration} دقيقة` : null },
    { icon: Clapperboard, label: 'الاستوديو', value: anime.studios.length ? anime.studios.join('، ') : null },
  ].filter((f) => f.value);

  return (
    <article>
      <div className="relative -mt-0 h-56 overflow-hidden sm:h-80">
        {(anime.bannerImage || cover) && (
          <Image src={(anime.bannerImage ?? cover) as string} alt="" fill priority sizes="100vw" className={anime.bannerImage ? 'object-cover' : 'object-cover blur-2xl scale-110'} />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-base via-base/60 to-base/30" />
      </div>

      <div className="container-page -mt-24 space-y-10 sm:-mt-32">
        <div className="flex flex-col gap-6 md:flex-row">
          <div className="glass relative mx-auto aspect-[2/3] w-44 shrink-0 overflow-hidden rounded-2xl shadow-glow md:mx-0 md:w-60">
            {cover && <Image src={cover} alt={title} fill priority sizes="240px" className="object-cover" />}
          </div>

          <div className="flex-1 space-y-4 md:pt-24">
            <div className="space-y-1">
              <h1 dir="auto" className="text-2xl font-extrabold leading-tight sm:text-4xl">{title}</h1>
              {otherTitles.map((t) => (
                <p key={t} dir="auto" className="text-sm text-muted">{t}</p>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <RatingBadge score={anime.averageScore} />
              {anime.genres.map((g) => (
                <Link key={g} href={`/browse?genre=${encodeURIComponent(g)}`} className="chip">
                  {GENRE_AR[g] ?? g}
                </Link>
              ))}
            </div>

            <div className="flex flex-wrap gap-3">
              {aired > 0 && (
                <Link href={`/watch/${anime.id}/1`} className="btn-primary">
                  <Play className="h-4 w-4 fill-current" /> ابدأ المشاهدة
                </Link>
              )}
              <FavoriteButton anime={anime} />
              <FollowButton anime={anime} />
            </div>
          </div>
        </div>

        <dl className="glass grid grid-cols-2 gap-4 rounded-2xl p-5 sm:grid-cols-3 lg:grid-cols-6">
          {facts.map((f) => (
            <div key={f.label} className="space-y-1">
              <dt className="flex items-center gap-1.5 text-xs text-muted">
                <f.icon className="h-3.5 w-3.5" /> {f.label}
              </dt>
              <dd className="text-sm font-semibold">{f.value}</dd>
            </div>
          ))}
        </dl>

        <section>
          <SectionHeader title="القصة" />
          <p className="glass max-w-4xl whitespace-pre-line rounded-2xl p-5 text-sm leading-loose text-fg/90">
            {cleanDescription(anime.description) || 'لا يتوفر وصف لهذا الأنمي بعد.'}
          </p>
        </section>

        <section>
          <SectionHeader title="الحلقات" />
          {aired > 0 ? (
            <EpisodeList animeId={anime.id} total={aired} />
          ) : (
            <EmptyState icon={Film} title="لم تُعرض أي حلقة بعد" description="ستظهر قائمة الحلقات هنا فور بدء العرض." />
          )}
        </section>

        {anime.characters.length > 0 && (
          <section>
            <SectionHeader title="الشخصيات الرئيسية" />
            <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
              {anime.characters.map(({ node, role }) => (
                <li key={node.id} className="glass overflow-hidden rounded-2xl">
                  <div className="relative aspect-square bg-surface">
                    {node.image.large && <Image src={node.image.large} alt={node.name.full ?? ''} fill sizes="(max-width:640px) 45vw, 16vw" className="object-cover" />}
                  </div>
                  <div className="p-3">
                    <p dir="auto" className="line-clamp-1 text-sm font-semibold">{node.name.full}</p>
                    <p className="text-xs text-muted">{ROLE_AR[role] ?? role}</p>
                  </div>
                </li>
              ))}
            </ul>
          </section>
        )}

        {anime.staff.length > 0 && (
          <section>
            <SectionHeader title="طاقم العمل" />
            <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {anime.staff.map(({ node, role }) => (
                <li key={`${node.id}-${role}`} className="glass flex items-center gap-3 rounded-2xl p-3">
                  <span className="relative h-12 w-12 shrink-0 overflow-hidden rounded-full bg-surface">
                    {node.image.medium && <Image src={node.image.medium} alt="" fill sizes="48px" className="object-cover" />}
                  </span>
                  <span className="min-w-0">
                    <span dir="auto" className="block truncate text-sm font-semibold">{node.name.full}</span>
                    {role && <span dir="auto" className="block truncate text-xs text-muted">{role}</span>}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>
    </article>
  );
}
