'use client';

import { ErrorState } from '@/components/ErrorState';

export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="container-page py-20">
      <ErrorState message="حدث خطأ غير متوقع أثناء عرض الصفحة." onRetry={reset} />
    </div>
  );
}
