import { NextRequest, NextResponse } from 'next/server';
import { AniListError } from '@/lib/anilist';
import { fetchPage } from '@/lib/anime-service';
import { GENRES, SEASON_VALUES, SORT_VALUES, STATUS_VALUES } from '@/lib/constants';
import type { BrowseParams, MediaSeason, MediaSort, MediaStatus } from '@/lib/types';

function pick<T extends string>(value: string | null, allowed: readonly T[]): T | undefined {
  return value && (allowed as readonly string[]).includes(value) ? (value as T) : undefined;
}

function int(value: string | null, min: number, max: number): number | undefined {
  if (!value) return undefined;
  const n = Number(value);
  return Number.isInteger(n) && n >= min && n <= max ? n : undefined;
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const genreValues = GENRES.map((g) => g[0]);
  const params: BrowseParams = {
    search: sp.get('q')?.trim().slice(0, 100) || undefined,
    genre: pick(sp.get('genre'), genreValues),
    year: int(sp.get('year'), 1950, new Date().getFullYear() + 2),
    status: pick<MediaStatus>(sp.get('status'), STATUS_VALUES),
    season: pick<MediaSeason>(sp.get('season'), SEASON_VALUES),
    sort: pick<MediaSort>(sp.get('sort'), SORT_VALUES),
    page: int(sp.get('page'), 1, 500) ?? 1,
    perPage: int(sp.get('perPage'), 1, 50) ?? 24,
  };
  try {
    const data = await fetchPage(params, 300);
    return NextResponse.json(data, {
      headers: { 'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=600' },
    });
  } catch (e) {
    const message = e instanceof AniListError ? e.message : 'حدث خطأ غير متوقع';
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
