import { NextRequest, NextResponse } from 'next/server';
import { providers } from '@/lib/providers/registry';
import type { ServerSource } from '@/lib/providers/types';
import { getAllowedHosts, isAllowedEmbedUrl } from '@/lib/security';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const animeId = Number(sp.get('animeId'));
  const episode = Number(sp.get('episode'));
  if (!Number.isInteger(animeId) || animeId <= 0 || !Number.isInteger(episode) || episode <= 0 || episode > 5000) {
    return NextResponse.json({ error: 'معاملات غير صالحة' }, { status: 400 });
  }

  const hosts = getAllowedHosts();
  const results = await Promise.allSettled(
    providers.map((p) => (p.isConfigured() ? p.getServers({ animeId, episode }) : Promise.resolve([] as ServerSource[]))),
  );

  const servers: ServerSource[] = [];
  let rejected = 0;
  const status = providers.map((p, i) => {
    const r = results[i];
    if (r.status === 'fulfilled') {
      for (const s of r.value) {
        if (isAllowedEmbedUrl(s.url, hosts)) servers.push(s);
        else rejected++;
      }
    }
    return { id: p.id, name: p.name, configured: p.isConfigured(), ok: r.status === 'fulfilled' };
  });

  return NextResponse.json({ servers, providers: status, rejected, embedHostsConfigured: hosts.length > 0 });
}
